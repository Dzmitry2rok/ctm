from typing import Optional, Any, Union

from pydantic import BaseModel, Field


class PaginatedCtm(BaseModel):
    page: Optional[int] = None
    total_entries: Optional[int] = None
    total_pages: Optional[int] = None
    per_page: Optional[int] = None
    next_page: Optional[Any] = None
    previous_page: Optional[Any] = None


class PagedDTO(BaseModel):
    page: Optional[Union[str, int]] = Field(1)
    per_page: Optional[Union[str, int]] = Field(10)
