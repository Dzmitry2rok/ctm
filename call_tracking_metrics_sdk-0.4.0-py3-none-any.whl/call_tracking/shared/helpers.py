import asyncio
import functools
import logging
import time
from typing import Callable

from shared.lazy import LazyObject


class Helpers:
    @staticmethod
    def method_dispatch(func: Callable) -> Callable:
        dispatcher = functools.singledispatch(func)

        def wrapper(*args, **kw):
            """ """
            return dispatcher.dispatch(args[1].__class__)(*args, **kw)

        wrapper.register = dispatcher.register
        functools.update_wrapper(wrapper, func)
        return wrapper

    @staticmethod
    def timer(logger: logging.Logger):
        def inner(func):
            async def process(func, *args, **params):
                if asyncio.iscoroutinefunction(func):
                    logger.debug(f"this function is a coroutine: {func.__name__}")
                    return await func(*args, **params)
                else:
                    logger.debug("this is not a coroutine")
                    return func(*args, **params)

            async def helper(*args, **params):
                logger.debug(f"{func.__name__}.time")
                start = time.perf_counter()
                result = await process(func, *args, **params)
                logger.debug(f">>> {time.perf_counter() - start}")
                return result

            return helper

        return inner


helpers = LazyObject(Helpers)
