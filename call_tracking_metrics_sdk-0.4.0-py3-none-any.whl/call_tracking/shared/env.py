from enum import Enum


class EnvMode(str, Enum):
    TEST: str = "test"
    PRODUCTION: str = "production"
