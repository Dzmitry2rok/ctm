import unittest
from typing import Type, Optional

from pydantic import BaseModel

from call_tracking.sdk.v1.configuration import Configuration
from call_tracking.sdk.v1.configuration.factory import ConfigurationFactory
from call_tracking.sdk.v1.module import BaseModule
from call_tracking.sdk.v1.transport import HttpTransportAdapterInterface, TransportAdapter
from call_tracking.sdk.v1.use_case import EmptyCtmModuleQueryUseCase, EmptyCtmCommandUseCase
from call_tracking.shared.env import EnvMode


class TestModule(BaseModule[EmptyCtmModuleQueryUseCase, EmptyCtmCommandUseCase], module_name="test_module"):
    _query_use_case: Type[EmptyCtmModuleQueryUseCase] = EmptyCtmModuleQueryUseCase
    _command_use_case: Type[EmptyCtmCommandUseCase] = EmptyCtmCommandUseCase


class TestTransport(HttpTransportAdapterInterface):
    def patch_data(self, endpoint: str, body: BaseModel, *ignore, **kwargs):
        return {}

    def get_data(self, endpoint: str, query: BaseModel, *ignore, **kwargs):
        return {}

    def post_data(self, endpoint: str, body: BaseModel, *ignore, **kwargs):
        return {}

    def delete_data(self, endpoint: str, *ignore, **kwargs):
        return {}

    def update_data(self, endpoint: str, body: BaseModel, *ignore, **kwargs):
        return {}

    @classmethod
    def create(cls, configuration) -> TransportAdapter:
        cls.configuration = configuration
        cls.validate()
        return cls()

    @classmethod
    def validate(cls) -> bool:
        return True


class TestConfigurationFactory(ConfigurationFactory):
    def __init__(self, env: Optional[str] = None, api_version: Optional[str] = None):
        self.env_state = EnvMode.TEST.value
        self.version = api_version


class ModuleTestCase(unittest.TestCase):
    def setUp(self) -> None:
        configuration_factory = TestConfigurationFactory()
        configuration = Configuration()
        configuration.factory = configuration_factory
        configuration_data = configuration.create_own(access_key="test", secret_key="test", account_id="test")
        transport = TestTransport.create(configuration_data)
        self.module = TestModule.create(transport)

    def test_module_name(self):
        self.assertEqual(self.module.module_name, "test_module")

    def test_init_module(self):
        self.assertIsInstance(self.module.query, EmptyCtmModuleQueryUseCase)
        self.assertIsInstance(self.module.command, EmptyCtmCommandUseCase)
