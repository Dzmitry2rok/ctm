import unittest

from pydantic import BaseModel

from call_tracking.sdk.v1.decorators import formatter
from call_tracking.sdk.v1.use_case import FormatterUseCase


class DecoratorTestCase(unittest.TestCase):
    def test_formatter_decorator(self):
        @formatter(formatter_cls=FormatterUseCase[BaseModel])
        def mock_func(x: dict) -> BaseModel:
            return x  # noqa

        formatted = mock_func({})
        self.assertIsInstance(formatted, BaseModel)
