import unittest

from pydantic_factories import ModelFactory
from hypothesis import strategies as sp, given

from call_tracking.sdk.v1.configuration.settings import CTMSettingsV1Test
from call_tracking.sdk.v1.transport import TransportAdapter, HttpTransportAdapterInterface


class ConfigurationFactory(ModelFactory):
    __model__ = CTMSettingsV1Test


sp.register_type_strategy(CTMSettingsV1Test, sp.builds(ConfigurationFactory.build))


class TransportTestCase(unittest.TestCase):
    @given(sp.from_type(CTMSettingsV1Test))
    def test_transport_adapter_interface(self, configuration: CTMSettingsV1Test):
        with self.assertRaises(NotImplementedError):
            TransportAdapter.create(configuration)

    def test_transport_adapter_interface_validate(self):
        with self.assertRaises(NotImplementedError):
            TransportAdapter.validate()

    @given(sp.from_type(CTMSettingsV1Test))
    def test_http_transport_adapter_interface(self, configuration: CTMSettingsV1Test):
        with self.assertRaises(NotImplementedError):
            HttpTransportAdapterInterface.create(configuration)
