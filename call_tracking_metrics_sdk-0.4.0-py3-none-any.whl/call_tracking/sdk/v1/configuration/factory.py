import abc
from abc import ABC
from typing import Optional, Type

from call_tracking.shared.env import EnvMode
from call_tracking.sdk.v1.configuration.settings import AbstractCTMConfiguration, CTMSettingsV1, CTMSettingsV1Test

__all__ = ("Configuration", "ConfigurationFactory")

__default__: str = "default"


class AbstractConfigurationFactory(ABC):
    @abc.abstractmethod
    def fabric(self) -> AbstractCTMConfiguration:
        raise NotImplementedError


class ConfigurationFactory(AbstractConfigurationFactory):
    """Returns a config instance dependence"""

    _mapping: dict = {
        EnvMode.TEST.value: CTMSettingsV1Test,
        EnvMode.PRODUCTION.value: CTMSettingsV1,
        __default__: CTMSettingsV1,
    }

    def __init__(self, env: Optional[str] = None):
        self.env_state = env

    def fabric(self) -> AbstractCTMConfiguration:
        return self._mapping.get(self.env_state, self.__fallback())()

    def __fallback(self):
        return self._mapping.get(__default__)


class Configuration:
    _factory: AbstractConfigurationFactory
    _default_factory: Type[AbstractConfigurationFactory] = ConfigurationFactory

    @property
    def factory(self) -> AbstractConfigurationFactory:
        return self._factory

    @factory.setter
    def factory(self, factory: AbstractConfigurationFactory) -> None:
        self._factory = factory

    def __init__(self) -> None:
        self._factory = self._default_factory()

    def create_own(self, *, access_key: str, secret_key: str, account_id: str) -> AbstractCTMConfiguration:
        configuration = self._factory.fabric()
        configuration.ctm_access_key = access_key
        configuration.ctm_secret_key = secret_key
        configuration.ctm_account_id = account_id
        return configuration
