from abc import ABC
from typing import Optional

from decouple import config
from pydantic import BaseSettings

__all__ = ("AbstractCTMConfiguration", "CTMSettingsV1", "CTMSettingsV1Test")

API_URL: str = "api.calltrackingmetrics.com"


class AbstractCTMConfiguration(BaseSettings, ABC):
    _api_version: str = "1"
    ctm_api_url: str = config("_CTM_API_URL", default=API_URL)

    ctm_api_endpoint: str = config("CTM_API_ENDPOINT", default=f"/api/v{_api_version}")
    ctm_access_key: Optional[str] = config("CTM_ACCESS_KEY", default="a408483ddf56eb6b8262f40a0cd67aa9360139f1")
    ctm_secret_key: Optional[str] = config("CTM_SECRET_KEY", default="90b554eb91e27fc4b0d45b13bbb24fcdbe99")
    ctm_account_id: Optional[str] = config("CTM_ACCOUNT_ID", default=None)
    ctm_connection_timeout: Optional[float] = config("CTM_CONNECTION_TIMEOUT", default=2)


class CTMSettingsV1(AbstractCTMConfiguration):
    ...


class CTMSettingsV1Test(CTMSettingsV1):
    ctm_api_url: str = config("_CTM_API_URL", default="http://localhost")
