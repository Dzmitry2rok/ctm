from functools import wraps
from typing import Type, Callable, TypeVar

from call_tracking.sdk.v1.typed import FormatterDestinationType

RT = TypeVar("RT")


def formatter(*, formatter_cls: Type[FormatterDestinationType]) -> FormatterDestinationType:
    def inner(func: Callable[..., FormatterDestinationType]) -> Callable[..., FormatterDestinationType]:
        @wraps(func)
        def wrap(*args, **kwargs) -> FormatterDestinationType:
            result = func(*args, **kwargs)
            return formatter_cls.format(result, func.__annotations__["return"])

        return wrap

    return inner  # noqa
