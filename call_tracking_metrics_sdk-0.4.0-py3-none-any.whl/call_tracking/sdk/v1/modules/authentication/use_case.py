from typing import Type

from call_tracking.sdk.v1.decorators import formatter
from call_tracking.sdk.v1.modules.authentication.entity import AuthDTO, AuthData
from call_tracking.sdk.v1.transport import FormBoundaryTransportAdapterInterface, HttpTransportAdapterInterface
from call_tracking.sdk.v1.use_case import UseCaseInterface, FormatterUseCase


class AuthenticationQueryUseCase(UseCaseInterface[HttpTransportAdapterInterface]):
    ...


class AuthenticationCommandUseCase(UseCaseInterface[HttpTransportAdapterInterface]):
    _transport: Type[HttpTransportAdapterInterface] = FormBoundaryTransportAdapterInterface

    @formatter(formatter_cls=FormatterUseCase[AuthData])
    def login(self, username: str, password: str) -> AuthData:
        auth_dto = AuthDTO(user=username, password=password)
        return self.transport.post_data("authentication", auth_dto)
