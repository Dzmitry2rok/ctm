from typing import Type

from call_tracking.sdk.v1.module import BaseModule
from call_tracking.sdk.v1.modules.authentication.use_case import (
    AuthenticationQueryUseCase,
    AuthenticationCommandUseCase,
)


class AuthenticationModule(
    BaseModule[AuthenticationQueryUseCase, AuthenticationCommandUseCase], module_name="authentication"
):
    _query_use_case: Type[AuthenticationQueryUseCase] = AuthenticationQueryUseCase
    _command_use_case: Type[AuthenticationCommandUseCase] = AuthenticationCommandUseCase
