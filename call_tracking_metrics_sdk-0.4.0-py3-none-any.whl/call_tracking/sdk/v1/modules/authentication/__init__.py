from .module import AuthenticationModule  # noqa
