import json
import unittest
from http.client import HTTPSConnection
from typing import Optional
from unittest.mock import patch, MagicMock

from hypothesis import strategies as sp, given
from pydantic import BaseModel
from pydantic_factories import ModelFactory

from call_tracking.sdk.v1.application.transport.http.transport import HttpAuthTransportAdapter
from call_tracking.sdk.v1.configuration import ConfigurationFactory, Configuration
from call_tracking.sdk.v1.modules import AuthenticationModule
from call_tracking.sdk.v1.modules.authentication.entity import AuthData
from call_tracking.shared.env import EnvMode


class AuthDataFactory(ModelFactory):
    __model__ = AuthData


sp.register_type_strategy(AuthData, sp.builds(AuthDataFactory.build))


class TestConfigurationFactory(ConfigurationFactory):
    def __init__(self, env: Optional[str] = None, api_version: Optional[str] = None):
        self.env_state = EnvMode.TEST.value
        self.version = api_version


class FakeHTTPConnection:
    def __init__(self, status, result="{}"):
        self.status = status
        self.result = result

    def request(self, method, url, body=None, headers={}, *, encode_chunked=False):
        # If you need to do any logic to change what is returned, you can do it in this class
        pass

    def getresponse(self):
        return FakeHTTPResponse(self.status, self.result)


class FakeHTTPResponse:
    def __init__(self, status, result="{}"):
        self.status = status
        self.result = result

    def read(self):
        return self.result


class TestDto(BaseModel):
    test: str


class HttpTransportTestCase(unittest.TestCase):
    def setUp(self) -> None:
        configuration_factory = TestConfigurationFactory()
        configuration = Configuration()
        configuration.factory = configuration_factory
        configuration_data = configuration.create_own(access_key="test", secret_key="test", account_id="test")
        self.transport = HttpAuthTransportAdapter.create(configuration_data)
        self.module = AuthenticationModule.create(self.transport)

    def test_connection(self):
        self.assertIsInstance(self.transport.connection, HTTPSConnection)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, json.dumps(AuthDataFactory.build().dict()))),
    )
    @given(sp.text(), sp.text())
    def test_get_webhooks(self, username, password):
        result = self.module.command.login(username, password)
        self.assertIsNotNone(result)
        self.assertIsInstance(result, AuthData)
