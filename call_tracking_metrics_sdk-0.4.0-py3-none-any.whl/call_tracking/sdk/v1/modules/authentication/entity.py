from pydantic import BaseModel


class AuthDTO(BaseModel):
    user: str
    password: str


class FirstAccount(BaseModel):
    id: int
    balance: str
    name: str


class AuthData(BaseModel):
    success: bool
    token: str
    expires: str
    email: str
    id: str
    accounts: int
    first_account: FirstAccount
