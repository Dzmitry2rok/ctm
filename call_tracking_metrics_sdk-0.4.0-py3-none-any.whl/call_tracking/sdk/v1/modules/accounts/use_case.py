from call_tracking.sdk.v1.decorators import formatter
from call_tracking.sdk.v1.modules.accounts.entity.account import Accounts
from call_tracking.sdk.v1.transport import HttpTransportAdapterInterface
from call_tracking.sdk.v1.use_case import UseCaseInterface, FormatterUseCase


class AccountQueryUseCase(UseCaseInterface[HttpTransportAdapterInterface]):
    _accounts_url: str = "/accounts"

    @formatter(formatter_cls=FormatterUseCase[Accounts])
    def get_accounts_list(self) -> Accounts:
        return self.transport.get_data(self._accounts_url)


class AccountCommandUseCase(UseCaseInterface[HttpTransportAdapterInterface]):
    ...
