from typing import Type

from call_tracking.sdk.v1.module import BaseModule
from call_tracking.sdk.v1.modules.accounts.use_case import AccountQueryUseCase, AccountCommandUseCase


class AccountsModule(BaseModule[AccountQueryUseCase, AccountCommandUseCase], module_name="account"):
    _query_use_case: Type[AccountQueryUseCase] = AccountQueryUseCase
    _command_use_case: Type[AccountCommandUseCase] = AccountCommandUseCase
