from .module import AccountsModule  # noqa
