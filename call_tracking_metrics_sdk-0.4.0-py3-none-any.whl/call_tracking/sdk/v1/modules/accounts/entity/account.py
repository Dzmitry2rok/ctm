from typing import Optional, List

from pydantic import Field, BaseModel

from call_tracking.shared.entity import PaginatedCtm


class Account(BaseModel):
    id: Optional[int] = None
    name: Optional[str] = None
    user_role: Optional[str] = None
    status: Optional[str] = None
    created: Optional[str] = None
    updated: Optional[str] = None
    canceled: Optional[str] = None
    voice_menus_url: Optional[str] = None
    numbers_url: Optional[str] = None
    user_licenses_url: Optional[str] = None
    receiving_numbers_url: Optional[str] = None
    sources_url: Optional[str] = None
    users_url: Optional[str] = None
    webhooks_url: Optional[str] = None
    calls_url: Optional[str] = None
    queues_url: Optional[str] = None
    schedules_url: Optional[str] = None
    geo_routes_url: Optional[str] = None
    url: Optional[str] = None
    agency_id: Optional[int] = None


class Accounts(PaginatedCtm):
    accounts: Optional[List[Account]] = Field([])
