import copy
from typing import Union, Optional, List

from pydantic import BaseModel

from call_tracking.sdk.v1.decorators import formatter
from call_tracking.sdk.v1.modules.activities.entity import (
    Call,
    Calls,
    CreateUpdateSaleRecordDTO,
    OperationResult,
    Note,
    AddNoteDTO,
    UpdateNoteDTO,
    DeleteNoteDTO,
)
from call_tracking.sdk.v1.modules.activities.entity.dto import TagListUpdateDTO
from call_tracking.sdk.v1.modules.activities.helpers import ActivitiesModuleHelper
from call_tracking.sdk.v1.transport import HttpTransportAdapterInterface
from call_tracking.sdk.v1.use_case import UseCaseInterface, FormatterUseCase
from call_tracking.shared.entity import PagedDTO


class ActivitiesQueryUseCase(
    UseCaseInterface[HttpTransportAdapterInterface],
    ActivitiesModuleHelper,
):
    @formatter(formatter_cls=FormatterUseCase[Calls])
    def get_list_of_activities(self, page: int = 1) -> Calls:
        """Get Paginated activities (calls/forms/etc)
        Args:
            page: page number for navigate

        Returns:
            Calls
        """
        paged: PagedDTO = PagedDTO(page=page)
        return self.transport.get_data("calls", paged)

    @formatter(formatter_cls=FormatterUseCase[Calls])
    def filter_list_of_activities(self, filters: Union[BaseModel, None] = None) -> Calls:
        """Get filtered result with pagination

        Example::
            # create a filter object
            filters: FilterDTO = activities.helper.create_activity_filter(filters='2152403074')
            paged_activities_filter = activities.query.filter_list_of_activities(filters)

        Args:
            filters(FilterDTO): filters object from helper `create_activity_filter`

        Returns:
            Calls: Calls python object
        """
        return self.transport.get_data("calls", filters)

    @formatter(formatter_cls=FormatterUseCase[Call])
    def get_activity_details_by_id(self, activity_detail_id: int) -> Call:
        """Get activity data by ID
        Creates a Call object or raise error if id is unknown

        Args:
            activity_detail_id(int): activity

        Returns:
            Call: Call Python object
        """
        return self.transport.get_data(f"calls/{activity_detail_id}")

    @formatter(formatter_cls=FormatterUseCase[Call])
    def process_webhook(self, call_data: dict) -> Call:
        return call_data  # noqa


class CommentActivityUseCaseMixin:
    _add_comment_uri: str = f"/calls/{{call_id}}/add_comment"
    _update_comment_uri: str = f"/calls/{{call_id}}/update_comment"
    _delete_comment_uri: str = f"/calls/{{call_id}}/delete_comment"

    @staticmethod
    def create_note_dto(activity_id: int, note: str, user_email: Optional[str] = None):
        return AddNoteDTO(
            call_id=activity_id,
            note=note,
            user=user_email,
        )

    @staticmethod
    def update_note_dto(activity_id: int, note: str, note_id: int, user_email: Optional[str] = None):
        return UpdateNoteDTO(
            call_id=activity_id,
            note=note,
            note_id=note_id,
            user=user_email,
        )

    @staticmethod
    def delete_note_dto(activity_id: int, note_id: int):
        return DeleteNoteDTO(
            call_id=activity_id,
            note_id=note_id,
        )

    @formatter(formatter_cls=FormatterUseCase[Note])
    def add_note(self, note_dto: AddNoteDTO) -> Note:
        """
        Create new note
        """
        return self.transport.post_data(self._add_comment_uri.format(call_id=note_dto.call_id), note_dto)

    @formatter(formatter_cls=FormatterUseCase[Note])
    def update_note(self, note_to_update_dto: UpdateNoteDTO) -> Note:
        """
        Update note by activity id and note id
        """
        return self.transport.post_data(
            self._update_comment_uri.format(call_id=note_to_update_dto.call_id), note_to_update_dto
        )

    def delete_note(self, delete_note_dto: DeleteNoteDTO) -> None:
        """
        Delete note by activity id and note id
        """
        self.transport.delete_data_payload(
            self._delete_comment_uri.format(call_id=delete_note_dto.call_id), delete_note_dto
        )


class ActivitiesCommandUseCase(
    UseCaseInterface[HttpTransportAdapterInterface], CommentActivityUseCaseMixin, ActivitiesModuleHelper
):
    _call_record_uri: str = f"/calls/{{call_id}}/sale"
    _activity_tag_url: str = f"/calls/{{activity_id}}/tag?tag={{tag}}"
    _activity_tag_list_url: str = f"/calls/{{activity_id}}/modify"
    _activity_spam_url: str = f"/calls/{{activity_id}}/spam"
    _activity_unspam_url: str = f"/calls/{{activity_id}}/unspam"
    _activity_assign_agent: str = f"/agents/{{agent_sid}}/assign_call?call_id={{activity_id}}"

    @staticmethod
    def create_sale_record_dto(
        call_id: Union[str, int],
        name: Optional[str] = None,
        score: Optional[int] = None,
        conversion: Optional[bool] = None,
        value: Optional[float] = None,
        sale_date: Optional[str] = None,
    ) -> CreateUpdateSaleRecordDTO:
        """Create a new `CreateUpdateSaleRecordDTO` for sale record

        Args:
            call_id(int): the call id from the call record
            name(str): reporting tag within the call log, typically used as a product name or sales person name
            score(int): integer between 1 and 5 to indicate the quality of the call
            conversion(bool): boolean flag (1 or 0) to indicate whether the call resulted in a sale
            value(float): numeric value to represent the total worth of the call in dollars
            sale_date(str): date (YYYY-MM-DD) when a sale occurred as a result of this call

        Returns:
            CreateUpdateSaleRecordDTO
        """
        return CreateUpdateSaleRecordDTO(
            call_id=call_id,
            name=name,
            score=score,
            conversion=conversion,
            value=value,
            sale_date=sale_date,
        )

    def create_sale_record(self, sale_record_dto: CreateUpdateSaleRecordDTO) -> None:
        """Create or update sale record data with CreateUpdateSaleRecordDTO
        Use `create_sale_record_dto` for build dto data

        Args:
            sale_record_dto(CreateUpdateSaleRecordDTO): DTO for send data

        Returns:
            None
        """
        self.transport.post_data(self._call_record_uri.format(call_id=sale_record_dto.call_id), sale_record_dto)

    def delete_sale_record(self, activity_id: int) -> None:
        """Delete sale record info by

        Args:
            activity_id(int): activity to delete

        Returns:
            None
        """
        self.transport.delete_data(self._call_record_uri.format(call_id=activity_id))

    @formatter(formatter_cls=FormatterUseCase[OperationResult])
    def add_tag_by_activity_id(self, activity_id: int, tag: str) -> OperationResult:
        """
        Add a new tag for activity
        Args:
            activity_id: id of activity
            tag: tag name string

        Returns:
            OperationResult object
        """
        url = self._activity_tag_url.format(activity_id=activity_id, tag=tag)
        return self.transport.patch_data(url)

    @formatter(formatter_cls=FormatterUseCase[OperationResult])
    def remove_tag_by_activity_id_and_tag(self, activity_id: int, tag: str) -> OperationResult:
        """
        Remove activity tag
        Args:
            activity_id: id of activity
            tag: tag name string

        Returns:
            OperationResult object
        """
        url = self._activity_tag_url.format(activity_id=activity_id, tag=tag)
        return self.transport.delete_data(url)

    @formatter(formatter_cls=FormatterUseCase[Call])
    def __get_activity_details_by_id(self, activity_detail_id: int) -> Call:
        """TODO: implement inject of query"""
        return self.transport.get_data(f"calls/{activity_detail_id}")

    def _get_current_tag_list(self, activity_detail_id: int) -> List[str]:
        """
        Load the current saved tags
        Args:
            activity_detail_id: id of activity

        Returns:
            List of tags
        """
        call = self.__get_activity_details_by_id(activity_detail_id)
        return call.tag_list

    @formatter(formatter_cls=FormatterUseCase[Call])
    def update_tag_list(self, activity_id: int, known_tags: List[str], tags: List[str]) -> Call:
        """
        Update the list tags
        Provide an original tags as known tags

        Args:
            activity_id: id of activity
            known_tags: list of already known tags
            tags: list of tags to be

        Returns:
            Activity data
        """
        url = self._activity_tag_list_url.format(activity_id=activity_id)
        current_tags = self._get_current_tag_list(activity_id)
        tags_to_update = self.__actualize_tags(current_tags, known_tags, tags)
        return self.transport.post_data(url, body=TagListUpdateDTO(tag_list=tags_to_update))

    def __actualize_tags(self, current_tags: List[str], known_tags: List[str], tags: List[str]) -> List[str]:
        """
        Create a new tag list
        Args:
            current_tags: already available tags
            known_tags: list of already known tags
            tags: tags to update

        Returns:
            List of new tags
        """
        tags_to_update = copy.copy(tags)
        current_tags = set(current_tags).difference(known_tags)
        tags_to_update.extend(current_tags)
        return list(set(tags_to_update))

    def mark_activity_as_spam(self, activity_id: int) -> None:
        """Mark activity as spam
        Args:
            activity_id: id of activity

        Returns:
            Empty result
        """
        url = self._activity_spam_url.format(activity_id=activity_id)
        self.transport.post_data(url)

    def mark_activity_as_not_spam(self, activity_id: int) -> None:
        """
        Mark activity as not spam
        Args:
            activity_id: id of activity

        Returns:
            Empty result
        """
        url = self._activity_unspam_url.format(activity_id=activity_id)
        self.transport.post_data(url)

    def assign_agent(self, activity_id: int, agent_sid: str) -> None:
        """
        Assign an agent to activity
        Args:
            activity_id: id of activity
            agent_sid: agent ID from users module

        Returns:
            Empty result
        """
        url = self._activity_assign_agent.format(activity_id=activity_id, agent_sid=agent_sid)
        self.transport.post_data(url)
