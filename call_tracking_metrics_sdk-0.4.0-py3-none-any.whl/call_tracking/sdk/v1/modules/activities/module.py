from typing import Type

from call_tracking.sdk.v1.module import BaseModule
from call_tracking.sdk.v1.modules.activities.use_case import ActivitiesQueryUseCase, ActivitiesCommandUseCase


class ActivitiesModule(BaseModule[ActivitiesQueryUseCase, ActivitiesCommandUseCase], module_name="activities"):
    _query_use_case: Type[ActivitiesQueryUseCase] = ActivitiesQueryUseCase
    _command_use_case: Type[ActivitiesCommandUseCase] = ActivitiesCommandUseCase
