import json
import unittest
from http.client import HTTPSConnection
from typing import Optional
from unittest.mock import patch, MagicMock

from hypothesis import given, strategies as sp
from pydantic import BaseModel
from pydantic_factories import ModelFactory

from call_tracking.sdk.v1 import ActivitiesModule
from call_tracking.sdk.v1.application.transport.http.transport import HttpAuthTransportAdapter
from call_tracking.sdk.v1.configuration import ConfigurationFactory, Configuration
from call_tracking.sdk.v1.modules.activities.entity import (
    Calls,
    Call,
    FilterDTO,
    CreateUpdateSaleRecordDTO,
    OperationResult,
)
from call_tracking.shared.env import EnvMode


class CallsFactory(ModelFactory):
    __model__ = Calls


class CallFactory(ModelFactory):
    __model__ = Call


class FilterDTOFactory(ModelFactory):
    __model__ = FilterDTO


class CreateUpdateSaleRecordDTOFactory(ModelFactory):
    __model__ = CreateUpdateSaleRecordDTO


class OperationResultFactory(ModelFactory):
    __model__ = OperationResult


sp.register_type_strategy(FilterDTO, sp.builds(FilterDTOFactory.build))
sp.register_type_strategy(Call, sp.builds(CallFactory.build))
sp.register_type_strategy(CreateUpdateSaleRecordDTO, sp.builds(CreateUpdateSaleRecordDTOFactory.build))
sp.register_type_strategy(OperationResult, sp.builds(OperationResultFactory.build))


class TestConfigurationFactory(ConfigurationFactory):
    def __init__(self, env: Optional[str] = None, api_version: Optional[str] = None):
        self.env_state = EnvMode.TEST.value
        self.version = api_version


class FakeHTTPConnection:
    def __init__(self, status, result="{}"):
        self.status = status
        self.result = result

    def request(self, method, url, body=None, headers={}, *, encode_chunked=False):
        # If you need to do any logic to change what is returned, you can do it in this class
        pass

    def getresponse(self):
        return FakeHTTPResponse(self.status, self.result)


class FakeHTTPResponse:
    def __init__(self, status, result="{}"):
        self.status = status
        self.result = result

    def read(self):
        return self.result


class TestDto(BaseModel):
    test: str


class HttpTransportTestCase(unittest.TestCase):
    def setUp(self) -> None:
        configuration_factory = TestConfigurationFactory()
        configuration = Configuration()
        configuration.factory = configuration_factory
        configuration_data = configuration.create_own(access_key="test", secret_key="test", account_id="test")
        self.transport = HttpAuthTransportAdapter.create(configuration_data)
        self.activities = ActivitiesModule.create(self.transport)

    def test_connection(self):
        self.assertIsInstance(self.transport.connection, HTTPSConnection)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, json.dumps(CallsFactory.build().dict()))),
    )
    def test_get_list_of_activities(self):
        result = self.activities.query.get_list_of_activities()
        self.assertIsNotNone(result)
        self.assertIsInstance(result, Calls)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, json.dumps(CallFactory.build().dict()))),
    )
    @given(sp.integers())
    def test_get_activity_details_by_id(self, activity_detail_id):
        result = self.activities.query.get_activity_details_by_id(activity_detail_id)
        self.assertIsNotNone(result)
        self.assertIsInstance(result, Call)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, json.dumps(CallsFactory.build().dict()))),
    )
    @given(sp.from_type(FilterDTO))
    def test_filter_list_of_activities(self, filters):
        result = self.activities.query.filter_list_of_activities(filters)
        self.assertIsNotNone(result)
        self.assertIsInstance(result, Calls)

    @given(sp.from_type(FilterDTO))
    def test_create_activity_filter(self, filter):
        filters = self.activities.query.create_activity_filter(**filter.dict())
        self.assertIsInstance(filters, FilterDTO)

    @given(sp.from_type(Call))
    def test_process_webhook(self, call_data: Call):
        call = self.activities.query.process_webhook(call_data.dict())
        self.assertIsInstance(call, Call)

    @given(sp.from_type(CreateUpdateSaleRecordDTO))
    def test_create_sale_record_dto(self, sale_record: CreateUpdateSaleRecordDTO):
        sale_record = self.activities.command.create_sale_record_dto(**sale_record.dict())
        self.assertIsInstance(sale_record, CreateUpdateSaleRecordDTO)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(
            return_value=FakeHTTPConnection(200, json.dumps(CreateUpdateSaleRecordDTOFactory.build().dict()))
        ),
    )
    @given(sp.from_type(CreateUpdateSaleRecordDTO))
    def test_create_sale_record(self, sale_record: CreateUpdateSaleRecordDTO):
        completed = self.activities.command.create_sale_record(sale_record)
        self.assertIsInstance(sale_record, CreateUpdateSaleRecordDTO)
        self.assertIsNone(completed)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, "{}")),
    )
    @given(sp.integers())
    def test_delete_sale_record(self, sale_record_id: int):
        completed = self.activities.command.delete_sale_record(sale_record_id)
        self.assertIsNone(completed)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, json.dumps(OperationResultFactory.build().dict()))),
    )
    @given(sp.integers(), sp.text())
    def test_add_tag_by_activity_id(self, activity_id: int, tag: str):
        completed = self.activities.command.add_tag_by_activity_id(activity_id, tag)
        self.assertIsInstance(completed, OperationResult)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, json.dumps(OperationResultFactory.build().dict()))),
    )
    @given(sp.integers(), sp.text())
    def test_remove_tag_by_activity_id_and_tag(self, activity_id: int, tag: str):
        completed = self.activities.command.remove_tag_by_activity_id_and_tag(activity_id, tag)
        self.assertIsInstance(completed, OperationResult)
