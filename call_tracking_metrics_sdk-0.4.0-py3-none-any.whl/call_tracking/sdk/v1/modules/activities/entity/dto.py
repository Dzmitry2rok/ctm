from typing import Optional, List

from pydantic import BaseModel

from call_tracking.shared.entity import PagedDTO


class FilterDTO(PagedDTO):
    filter: Optional[str] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    start_day: Optional[str] = None
    contact_number: Optional[str] = None


class TagListUpdateDTO(BaseModel):
    tag_list: List[str]
