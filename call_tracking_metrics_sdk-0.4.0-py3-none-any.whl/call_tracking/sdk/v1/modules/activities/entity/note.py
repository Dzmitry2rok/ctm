from typing import Optional, Union

from pydantic import BaseModel

__all__ = ("AddNoteDTO", "UpdateNoteDTO", "DeleteNoteDTO")


class CallId(BaseModel):
    call_id: Union[str, int]


class AddNoteDTO(CallId):
    note: str
    user: Optional[str]


class UpdateNoteDTO(AddNoteDTO):
    note_id: int


class DeleteNoteDTO(CallId):
    note_id: int
