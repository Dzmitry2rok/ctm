from typing import Union, Optional

from pydantic import BaseModel, Field

__all__ = ("CreateUpdateSaleRecordDTO", "DeleteSaleRecordDTO")


class CallId(BaseModel):
    call_id: Union[str, int]


class CreateUpdateSaleRecordDTO(CallId):
    name: Optional[str]
    score: Optional[int] = Field(ge=1, le=5)
    conversion: Optional[bool]
    value: Optional[float]
    sale_date: Optional[str]


class DeleteSaleRecordDTO(CallId):
    ...
