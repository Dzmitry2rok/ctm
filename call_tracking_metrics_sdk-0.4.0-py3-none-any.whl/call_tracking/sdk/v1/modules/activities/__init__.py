from .module import ActivitiesModule  # noqa
