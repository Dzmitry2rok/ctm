from typing import Optional, Union

from call_tracking.sdk.v1.modules.activities.entity import FilterDTO


class ActivitiesModuleHelper:
    @staticmethod
    def create_activity_filter(
        filter: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        start_day: Optional[str] = None,
        contact_number: Optional[str] = None,
        page: Optional[Union[str, int]] = None,
        per_page: Optional[Union[str, int]] = None,
    ):
        """Create a filter for get activities data

        Args:
            filter: search string to look for messages with specific callerid, caller_number, called_number, source name, etc.
            end_date(str): the end date for the search (YYYY-MM-DD)
            start_day(str): used with time_duration and weeks to denote the first day of the week. for example, start_day=Sunday. the default is Monday
            contact_number(str): prefixed based searching and filtering by the contact phone number
            page(str): the page number
            per_page(int): items per page

        Returns:
            FilterDTO: filter object
        """
        return FilterDTO(
            filter=filter,
            start_date=start_date,
            end_date=end_date,
            start_day=start_day,
            contact_number=contact_number,
            page=page,
            per_page=per_page,
        )
