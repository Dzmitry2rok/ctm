from call_tracking.sdk.v1.decorators import formatter
from call_tracking.sdk.v1.modules.users.entity.users import Users, UsersShotInfo
from call_tracking.sdk.v1.transport import HttpTransportAdapterInterface
from call_tracking.sdk.v1.use_case import UseCaseInterface, FormatterUseCase
from call_tracking.shared.entity import PagedDTO


class UserQueryUseCase(UseCaseInterface[HttpTransportAdapterInterface]):
    _accounts_url: str = "/users/"

    @formatter(formatter_cls=FormatterUseCase[Users])
    def get_user_list(self) -> Users:
        page = PagedDTO(per_page=100)
        return self.transport.get_data(self._accounts_url, page)

    @formatter(formatter_cls=FormatterUseCase[UsersShotInfo])
    def get_user_short_info_list(self) -> UsersShotInfo:
        page = PagedDTO(per_page=100)
        return self.transport.get_data(self._accounts_url, page)


class UserCommandUseCase(UseCaseInterface[HttpTransportAdapterInterface]):
    ...
