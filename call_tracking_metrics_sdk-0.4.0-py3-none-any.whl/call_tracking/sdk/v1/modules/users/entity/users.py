from typing import Optional, List, Any, Dict

from pydantic import BaseModel, Field, root_validator

from call_tracking.shared.entity import PaginatedCtm


class SipPhone(BaseModel):
    uri: Optional[str] = None


class OutboundNumber(BaseModel):
    id: Optional[str] = None
    country_code: Optional[str] = None
    base_number: Optional[str] = None


class UserShotInfo(BaseModel):
    id: Optional[str] = None
    uid: Optional[int] = None
    status: Optional[str] = None
    email: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    full_name: Optional[str] = None

    @root_validator
    def compute_full_name(cls, values) -> Dict:
        full_name = f"{values['first_name']} {values['last_name']}"
        values["full_name"] = full_name

        return values


class UsersShotInfo(PaginatedCtm):
    users: Optional[List[UserShotInfo]] = Field([])


class User(UserShotInfo):
    account_id: Optional[int] = None
    inbound_number: Optional[str] = None
    pic_url: Optional[Any] = None
    role: Optional[str] = None
    url: Optional[str] = None
    live_calls: Optional[List] = None
    language: Optional[str] = None
    desk_mode_default: Optional[bool] = None
    sip_phone: Optional[SipPhone] = None
    outbound_number: Optional[OutboundNumber] = None


class Users(PaginatedCtm):
    users: Optional[List[User]] = Field([])
