from typing import Type

from call_tracking.sdk.v1.module import BaseModule
from call_tracking.sdk.v1.modules.users.use_case import UserQueryUseCase, UserCommandUseCase


class UserModule(BaseModule[UserQueryUseCase, UserCommandUseCase], module_name="users"):
    _query_use_case: Type[UserQueryUseCase] = UserQueryUseCase
    _command_use_case: Type[UserCommandUseCase] = UserCommandUseCase
