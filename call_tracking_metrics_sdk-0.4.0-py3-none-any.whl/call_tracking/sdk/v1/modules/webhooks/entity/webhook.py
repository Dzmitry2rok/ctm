from typing import Optional, Any, List

from pydantic import BaseModel

from call_tracking.shared.entity import PaginatedCtm


class WebhookItem(BaseModel):
    id: Optional[int] = None
    name: Optional[str] = None
    description: Optional[Any] = None
    weburl: Optional[str] = None
    with_resource_url: Optional[bool] = None  # noqa
    position: Optional[str] = None
    username: Optional[Any] = None
    password: Optional[Any] = None
    client_type: Optional[str] = None
    client_id: Optional[int] = None
    webhook_conditions: Optional[List] = None
    account_id: Optional[int] = None


class WebhookList(PaginatedCtm):
    next_page: Optional[Any] = None
    previous_page: Optional[Any] = None
    webhooks: Optional[List[WebhookItem]] = None
