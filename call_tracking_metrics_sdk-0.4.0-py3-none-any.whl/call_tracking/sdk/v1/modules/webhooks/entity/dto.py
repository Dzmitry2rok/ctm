from typing import Optional

from pydantic import BaseModel


class UpdateWebhookDTO(BaseModel):
    weburl: str
    position: Optional[str] = None


class CreateWebhookDTO(UpdateWebhookDTO):
    name: Optional[str] = None
    hooktype: Optional[str] = None
