from typing import Optional

from call_tracking.sdk.v1.decorators import formatter
from call_tracking.sdk.v1.modules.webhooks.entity import WebhookList, CreateWebhookDTO, WebhookItem
from call_tracking.sdk.v1.modules.webhooks.entity.dto import UpdateWebhookDTO
from call_tracking.sdk.v1.transport import HttpTransportAdapterInterface
from call_tracking.sdk.v1.use_case import UseCaseInterface, FormatterUseCase
from call_tracking.shared.entity import PagedDTO


class WebhookQueryUseCase(
    UseCaseInterface[HttpTransportAdapterInterface],
):
    _webhook_url: str = "/webhooks"
    _webhook_detail_url: str = f"/{_webhook_url}/{{webhook_id}}"

    @formatter(formatter_cls=FormatterUseCase[WebhookList])
    def get_webhooks(self, page: int = 1) -> WebhookList:
        page: PagedDTO = PagedDTO(page=page)
        return self.transport.get_data(self._webhook_url, page)

    @formatter(formatter_cls=FormatterUseCase[WebhookItem])
    def get_webhook_by_id(self, webhook_id: int) -> WebhookItem:
        url = self._webhook_detail_url.format(webhook_id=webhook_id)
        return self.transport.get_data(url)


class WebhookCommandUseCase(
    UseCaseInterface[HttpTransportAdapterInterface],
):
    _webhook_create_url: str = "/webhooks"
    _webhook_update_url: str = f"/webhooks/{{webhook_id}}"
    _webhook_delete_url: str = f"/webhooks/{{webhook_id}}"

    @staticmethod
    def build_webhook_dto(
        weburl: str, name: Optional[str] = None, position: Optional[str] = None, hooktype: Optional[str] = None
    ) -> CreateWebhookDTO:
        return CreateWebhookDTO(
            weburl=weburl,
            name=name,
            position=position,
            hooktype=hooktype,
        )

    @staticmethod
    def build_update_dto(weburl: str, position: Optional[str] = None):
        return UpdateWebhookDTO(
            weburl=weburl,
            position=position,
        )

    @formatter(formatter_cls=FormatterUseCase[WebhookItem])
    def create_webhook(self, webhook_dto: CreateWebhookDTO) -> WebhookItem:
        return self.transport.post_data(self._webhook_create_url, webhook_dto)

    @formatter(formatter_cls=FormatterUseCase[WebhookItem])
    def update_webhook(self, webhook_id: int, webhook_update_dto: UpdateWebhookDTO) -> WebhookItem:
        url = self._webhook_update_url.format(webhook_id=webhook_id)
        return self.transport.update_data(url, webhook_update_dto)

    def delete_webhook(self, webhook_id: int) -> None:
        self.transport.delete_data(self._webhook_delete_url.format(webhook_id=webhook_id))
