import json
import unittest
from http.client import HTTPSConnection
from typing import Optional
from unittest.mock import patch, MagicMock

from hypothesis import given, strategies as sp, provisional
from pydantic import BaseModel
from pydantic_factories import ModelFactory

from call_tracking.sdk.v1 import WebhookModule
from call_tracking.sdk.v1.application.transport.http.transport import HttpAuthTransportAdapter
from call_tracking.sdk.v1.configuration import ConfigurationFactory, Configuration
from call_tracking.sdk.v1.modules.webhooks.entity import WebhookItem, WebhookList
from call_tracking.sdk.v1.modules.webhooks.entity.dto import UpdateWebhookDTO, CreateWebhookDTO
from call_tracking.shared.env import EnvMode


class CreateWebhookDTOFactory(ModelFactory):
    __model__ = CreateWebhookDTO


class UpdateWebhookDTOFactory(ModelFactory):
    __model__ = UpdateWebhookDTO


class WebhookItemFactory(ModelFactory):
    __model__ = WebhookItem


class WebhookListFactory(ModelFactory):
    __model__ = WebhookList


sp.register_type_strategy(CreateWebhookDTOFactory, sp.builds(CreateWebhookDTOFactory.build))
sp.register_type_strategy(UpdateWebhookDTO, sp.builds(UpdateWebhookDTOFactory.build))


class TestConfigurationFactory(ConfigurationFactory):
    def __init__(self, env: Optional[str] = None, api_version: Optional[str] = None):
        self.env_state = EnvMode.TEST.value
        self.version = api_version


class FakeHTTPConnection:
    def __init__(self, status, result="{}"):
        self.status = status
        self.result = result

    def request(self, method, url, body=None, headers={}, *, encode_chunked=False):
        # If you need to do any logic to change what is returned, you can do it in this class
        pass

    def getresponse(self):
        return FakeHTTPResponse(self.status, self.result)


class FakeHTTPResponse:
    def __init__(self, status, result="{}"):
        self.status = status
        self.result = result

    def read(self):
        return self.result


class TestDto(BaseModel):
    test: str


class HttpTransportTestCase(unittest.TestCase):
    def setUp(self) -> None:
        configuration_factory = TestConfigurationFactory()
        configuration = Configuration()
        configuration.factory = configuration_factory
        configuration_data = configuration.create_own(access_key="test", secret_key="test", account_id="test")
        self.transport = HttpAuthTransportAdapter.create(configuration_data)
        self.module = WebhookModule.create(self.transport)

    def test_connection(self):
        self.assertIsInstance(self.transport.connection, HTTPSConnection)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, json.dumps(WebhookListFactory.build().dict()))),
    )
    def test_get_webhooks(self):
        result = self.module.query.get_webhooks()
        self.assertIsNotNone(result)
        self.assertIsInstance(result, WebhookList)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, json.dumps(WebhookItemFactory.build().dict()))),
    )
    @given(sp.integers())
    def test_get_webhook_by_id(self, activity_detail_id):
        result = self.module.query.get_webhook_by_id(activity_detail_id)
        self.assertIsNotNone(result)
        self.assertIsInstance(result, WebhookItem)

    @given(weburl=provisional.urls(), name=sp.text(min_size=5, max_size=20), position=sp.characters(max_codepoint=20))
    def test_build_webhook_dto(self, weburl, name, position):
        result = self.module.command.build_webhook_dto(
            weburl=weburl,
            name=name,
            position=position,
        )
        self.assertIsNotNone(result)
        self.assertIsInstance(result, CreateWebhookDTO)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, json.dumps(CreateWebhookDTOFactory.build().dict()))),
    )
    @given(sp.from_type(CreateWebhookDTO))
    def test_create_webhook(self, webhook_data: CreateWebhookDTO):
        result = self.module.command.create_webhook(webhook_data)
        self.assertIsNotNone(result)
        self.assertIsInstance(result, WebhookItem)

    @given(weburl=provisional.urls(), position=sp.characters(max_codepoint=1))
    def test_build_update_dto(self, weburl, position):
        result = self.module.command.build_update_dto(
            weburl=weburl,
            position=position,
        )
        self.assertIsNotNone(result)
        self.assertIsInstance(result, UpdateWebhookDTO)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, json.dumps(WebhookItemFactory.build().dict()))),
    )
    @given(sp.integers(), sp.from_type(UpdateWebhookDTO))
    def test_update_webhook(self, webhook_id: int, data_to_update: CreateWebhookDTO):
        result = self.module.command.update_webhook(webhook_id, data_to_update)
        self.assertIsNotNone(result)
        self.assertIsInstance(result, WebhookItem)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, "{}")),
    )
    @given(sp.integers())
    def test_delete_webhook(self, webhook_id: int):
        result = self.module.command.delete_webhook(webhook_id)
        self.assertIsNone(result)
