from typing import Type

from call_tracking.sdk.v1.module import BaseModule
from call_tracking.sdk.v1.modules.webhooks.use_case import WebhookQueryUseCase, WebhookCommandUseCase


class WebhookModule(BaseModule[WebhookQueryUseCase, WebhookCommandUseCase], module_name="webhooks"):
    _query_use_case: Type[WebhookQueryUseCase] = WebhookQueryUseCase
    _command_use_case: Type[WebhookCommandUseCase] = WebhookCommandUseCase
