import logging
from abc import ABC
from typing import Optional, Type, Generic

from call_tracking.sdk.v1.mixin import TransportMixin
from call_tracking.sdk.v1.transport import HttpTransportAdapterInterface
from call_tracking.sdk.v1.typed import (
    FormatterDestinationType,
    TransportAdapterType,
    QueryUseCaseType,
)

logger = logging.getLogger(__name__)


class FormatterUseCase(Generic[FormatterDestinationType], ABC):
    @classmethod
    def format(cls, source: dict, destination: Type[FormatterDestinationType]) -> FormatterDestinationType:
        """Format source dict by destination type

        Args:
            source(dict): raw dict to convert to destination format
            destination(Type[FormatterDestinationType]): destination type

        Returns:
            FormatterDestinationType: converted object
        """
        return destination(**source)


class UseCaseInterface(Generic[TransportAdapterType], TransportMixin, ABC):
    def __init_subclass__(cls, transport: Optional[TransportAdapterType] = None, **kwargs):
        super().__init_subclass__(**kwargs)
        if transport:
            cls.transport = transport

    @classmethod
    def create(cls, transport: Optional[TransportAdapterType]) -> QueryUseCaseType:
        use_case = cls()
        use_case.transport = transport if transport else use_case.transport
        return use_case


class EmptyCtmModuleQueryUseCase(UseCaseInterface[HttpTransportAdapterInterface]):
    ...


class EmptyCtmCommandUseCase(UseCaseInterface[HttpTransportAdapterInterface]):
    ...
