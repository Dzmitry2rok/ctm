from call_tracking.sdk.v1.typed import TransportAdapterType


class TransportMixin:
    _transport: TransportAdapterType

    @property
    def transport(self):
        return self._transport

    @transport.setter
    def transport(self, transport: TransportAdapterType):
        self._transport = transport
