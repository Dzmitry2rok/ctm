from typing import Type, Generic

from call_tracking.sdk.v1.mixin import TransportMixin
from call_tracking.sdk.v1.transport import TransportAdapter
from call_tracking.sdk.v1.typed import QueryUseCaseType, CommandUseCaseType
from call_tracking.sdk.v1.use_case import (
    EmptyCtmModuleQueryUseCase,
    EmptyCtmCommandUseCase,
)


class BaseModule(Generic[QueryUseCaseType, CommandUseCaseType], TransportMixin):
    module_name: str = None

    _query_use_case: Type[QueryUseCaseType] = EmptyCtmModuleQueryUseCase
    _command_use_case: Type[CommandUseCaseType] = EmptyCtmCommandUseCase

    _query: QueryUseCaseType
    _command: CommandUseCaseType

    @property
    def query(self) -> QueryUseCaseType:
        return self._query

    @property
    def command(self) -> CommandUseCaseType:
        return self._command

    def __init_subclass__(cls, module_name: str = None, **kwargs):
        super().__init_subclass__(*kwargs)
        cls.module_name = module_name

    @classmethod
    def create(cls, transport: TransportAdapter):
        module = cls()
        module.transport = transport

        module._query = cls._query_use_case.create(module.transport)
        module._command = cls._command_use_case.create(module.transport)
        return module
