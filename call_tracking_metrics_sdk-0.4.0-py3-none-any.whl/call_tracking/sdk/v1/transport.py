import abc
from abc import ABC
from typing import Union

from pydantic import BaseModel

from call_tracking.sdk.v1.configuration.settings import AbstractCTMConfiguration


class TransportErrorHandler(ABC):
    @classmethod
    @abc.abstractmethod
    def handle(cls, code: Union[str, int], message: Union[None, str]):
        ...


class TransportAdapter(ABC):
    configuration: AbstractCTMConfiguration
    _error_handler: TransportErrorHandler

    @classmethod
    @abc.abstractmethod
    def create(cls, configuration: AbstractCTMConfiguration) -> "TransportAdapter":
        raise NotImplementedError

    @classmethod
    @abc.abstractmethod
    def validate(cls) -> bool:
        raise NotImplementedError


class HttpTransportAdapterInterface(TransportAdapter, ABC):
    @abc.abstractmethod
    def get_data(self, endpoint: str, query: BaseModel, *ignore, **kwargs):
        raise NotImplementedError

    @abc.abstractmethod
    def post_data(self, endpoint: str, body: BaseModel, *ignore, **kwargs):
        raise NotImplementedError

    @abc.abstractmethod
    def delete_data(self, endpoint: str, *ignore, **kwargs):
        raise NotImplementedError

    @abc.abstractmethod
    def update_data(self, endpoint: str, body: BaseModel, *ignore, **kwargs):
        raise NotImplementedError

    @abc.abstractmethod
    def patch_data(self, endpoint: str, body: BaseModel, *ignore, **kwargs):
        raise NotImplementedError


class FormBoundaryTransportAdapterInterface(HttpTransportAdapterInterface, ABC):
    _headers: dict = {"Content-type": "application/x-www-form-urlencoded", "Accept": "text/plain"}


class HttpTransportAdapterError(ValueError):
    ...
