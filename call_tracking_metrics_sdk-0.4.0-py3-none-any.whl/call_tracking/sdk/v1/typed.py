from typing import TypeVar

from pydantic import BaseModel

FormatterDestinationType = TypeVar("FormatterDestinationType", bound=BaseModel)
FormatterUseCaseType = TypeVar("FormatterUseCaseType", bound=BaseModel)
QueryUseCaseType = TypeVar("QueryUseCaseType")
CommandUseCaseType = TypeVar("CommandUseCaseType")

TransportAdapterType = TypeVar("TransportAdapterType")
