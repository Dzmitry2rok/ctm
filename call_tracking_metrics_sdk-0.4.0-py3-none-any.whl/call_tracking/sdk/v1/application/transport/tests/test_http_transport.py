import base64
import unittest
from http.client import HTTPSConnection
from typing import Optional
from unittest.mock import patch, MagicMock
from urllib.parse import urlencode

from hypothesis import strategies as sp, given, HealthCheck, settings
from pydantic import BaseModel
from pydantic_factories import ModelFactory

from call_tracking.sdk.v1.application.transport.http.transport import (
    HttpTransportAdapter,
    HttpAuthTransportAdapter,
    HttpFormBoundaryTransportAdapter,
)
from call_tracking.sdk.v1.configuration import ConfigurationFactory, Configuration
from call_tracking.sdk.v1.transport import HttpTransportAdapterError
from call_tracking.shared.env import EnvMode


class TestConfigurationFactory(ConfigurationFactory):
    def __init__(self, env: Optional[str] = None, api_version: Optional[str] = None):
        self.env_state = EnvMode.TEST.value
        self.version = api_version


class TestHttpTransportAdapter(HttpTransportAdapter):
    _headers: dict = {"Content-Type": "application/json"}

    def get_headers(self) -> dict:
        return self._headers

    @classmethod
    def validate(cls) -> bool:
        return True


class FakeHTTPConnection:
    def __init__(self, status, result="{}"):
        self.status = status
        self.result = result

    def request(self, method, url, body=None, headers={}, *, encode_chunked=False):
        # If you need to do any logic to change what is returned, you can do it in this class
        pass

    def getresponse(self):
        return FakeHTTPResponse(self.status, self.result)


class FakeHTTPResponse:
    def __init__(self, status, result="{}"):
        self.status = status
        self.result = result

    def read(self):
        return self.result


class TestDto(BaseModel):
    test: str


class UrlEncodeDTO(BaseModel):
    test: str
    test2: str


class SecretsDTO(BaseModel):
    access_key: str
    secret_key: str
    account_id: int


class TestDtoFactory(ModelFactory):
    __model__ = TestDto


class UrlEncodeDTOFactory(ModelFactory):
    __model__ = UrlEncodeDTO


class SecretsDTOFactory(ModelFactory):
    __model__ = SecretsDTO


sp.register_type_strategy(TestDto, sp.builds(TestDtoFactory.build))
sp.register_type_strategy(UrlEncodeDTO, sp.builds(UrlEncodeDTOFactory.build))
sp.register_type_strategy(SecretsDTO, sp.builds(SecretsDTOFactory.build))


class HttpTransportTestCase(unittest.TestCase):
    @settings(suppress_health_check=(HealthCheck.not_a_test_method,))
    @given(sp.from_type(SecretsDTO))
    def setUp(self, access: SecretsDTO) -> None:
        configuration_factory = TestConfigurationFactory()
        configuration = Configuration()
        configuration.factory = configuration_factory
        configuration_data = configuration.create_own(
            access_key=access.access_key, secret_key=access.secret_key, account_id=str(access.account_id)
        )
        self.transport = TestHttpTransportAdapter.create(configuration_data)
        self.transport_auth = HttpAuthTransportAdapter.create(configuration_data)
        self.transport_form = HttpFormBoundaryTransportAdapter.create(configuration_data)
        self.access = access

    def test_connection(self):
        self.assertIsInstance(self.transport.connection, HTTPSConnection)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, "{}")),
    )
    def test_get_data(self):
        result = self.transport.get_data("test")
        self.assertIsNotNone(result)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, "{}")),
    )
    def test_post_data(self):
        result = self.transport.post_data("test", body=BaseModel())
        self.assertIsNotNone(result)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, "{}")),
    )
    def test_delete_data(self):
        result = self.transport.delete_data("test")
        self.assertIsNotNone(result)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, "{}")),
    )
    def test_update_data(self):
        result = self.transport.update_data("test", body=BaseModel())
        self.assertIsNotNone(result)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, "{}")),
    )
    def test_patch_data(self):
        result = self.transport.patch_data("test")
        self.assertIsNotNone(result)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, "{}")),
    )
    @given(sp.from_type(TestDto))
    def test_get_data_with_query(self, query: TestDto):
        result = self.transport.get_data("test", query)
        self.assertIsNotNone(result)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, "{}")),
    )
    @given(sp.from_type(TestDto))
    def test_post_data_with_body(self, body: TestDto):
        result = self.transport.post_data("test", body=body)
        self.assertIsNotNone(result)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(403, "{}")),
    )
    @given(sp.from_type(TestDto))
    def test_post_data_403(self, body: TestDto):
        with self.assertRaises(HttpTransportAdapterError):
            self.transport.post_data("test", body=body)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(403, "<html")),
    )
    @given(sp.from_type(TestDto))
    def test_post_data_403_html_response(self, body: TestDto):
        with self.assertRaises(HttpTransportAdapterError):
            self.transport.post_data("test", body=body)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, "{}")),
    )
    @given(sp.from_type(TestDto))
    def test_post_data_transport_auth(self, body: TestDto):
        self.transport_auth.post_data("test", body=body)

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, "{}")),
    )
    @given(sp.from_type(UrlEncodeDTO))
    def test_post_data_transport_form(self, to_encode: UrlEncodeDTO):
        url_encode = self.transport_form._get_body(body=to_encode)
        self.assertEqual(url_encode, urlencode(to_encode.dict()))

    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HTTPSConnection",
        new=MagicMock(return_value=FakeHTTPConnection(200, "{}")),
    )
    @patch(
        "call_tracking.sdk.v1.application.transport.http.transport.HttpAuthTransportAdapter._get_secrets",
    )
    def test_ger_headers(self, secrets: MagicMock):
        secrets.return_value = f"{self.access.access_key}:{self.access.secret_key}"
        json_type_headers = {"Content-Type": "application/json"}
        self.assertEqual(self.transport.get_headers(), json_type_headers)
        self.assertIsNotNone(self.transport_auth.get_headers().get("Authorization"))
        auth_header = self.transport_auth._get_auth_header()
        test_user = (
            f"Basic {base64.standard_b64encode(f'{self.access.access_key}:{self.access.secret_key}'.encode()).decode()}"
        )
        self.assertEqual(auth_header.get("Authorization"), test_user)
