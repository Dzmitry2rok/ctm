import abc
import base64
import copy
import json
import logging
from abc import ABC
from functools import lru_cache
from http.client import HTTPSConnection
from json import JSONDecodeError
from logging import Logger
from typing import Union, TypedDict
from urllib.parse import urlencode

import requests
from pydantic import BaseModel

from call_tracking.sdk.v1.transport import (
    FormBoundaryTransportAdapterInterface,
    HttpTransportAdapterInterface,
    TransportErrorHandler,
    HttpTransportAdapterError,
)

from call_tracking.sdk.v1.configuration.settings import AbstractCTMConfiguration

__all__ = (
    "HttpAuthTransportAdapter",
    "HttpFormBoundaryTransportAdapter",
    "HttpAuthTransportAdapterForAccounts",
)

MessageErrorType = TypedDict("MessageErrorType", {"success": bool, "message": str})

logger: Logger = logging.getLogger(__name__)


class HttpTransportErrorHandler(TransportErrorHandler):
    @classmethod
    def handle(cls, code: Union[str, int], message: MessageErrorType):
        logger.error(f"HttpTransportAdapter error with code: {code} and message: {message['message']}")
        raise HttpTransportAdapterError(
            f"HttpTransportAdapter error with code: {code} and message: {message['message']}"
        )


class HttpTransportAdapter(HttpTransportAdapterInterface, ABC):
    _connection: HTTPSConnection = None
    _error_handler: HttpTransportErrorHandler = HttpTransportErrorHandler
    _headers: dict = {"Content-Type": "application/json"}

    @classmethod
    def create(cls, configuration: AbstractCTMConfiguration) -> "HttpTransportAdapter":
        cls.configuration = configuration
        cls.validate()
        return cls()

    @lru_cache
    def get_connection(self):
        if self._connection is not None:
            return self._connection
        self._connection = HTTPSConnection(
            self.configuration.ctm_api_url, 443, timeout=self.configuration.ctm_connection_timeout
        )
        return self._connection

    @property
    def connection(self) -> HTTPSConnection:
        return self.get_connection()

    def _get_endpoint(self, endpoint: str):
        return f"{self.configuration.ctm_api_endpoint}/{endpoint}"

    def _get_body(self, body: BaseModel):
        return json.dumps(body.dict())

    def get_data(self, endpoint: str, query: Union[BaseModel, None] = None, *ignore, **kwargs):
        self.connection.request(
            "GET", f"{self._get_endpoint(endpoint)}{self._get_query(query)}", headers=self.get_headers()
        )
        return self.process_transport_result()

    def post_data(self, endpoint: str, body: BaseModel = BaseModel(), *ignore, **kwargs):
        self.connection.request(
            "POST", self._get_endpoint(endpoint), body=self._get_body(body), headers=self.get_headers()
        )
        return self.process_transport_result()

    def delete_data(self, endpoint: str, *ignore, **kwargs):
        self.connection.request("DELETE", self._get_endpoint(endpoint), headers=self.get_headers())
        return self.process_transport_result()

    def delete_data_payload(self, endpoint: str, body: BaseModel, *ignore, **kwargs):
        self.connection.request(
            "DELETE", self._get_endpoint(endpoint), body=self._get_body(body), headers=self.get_headers()
        )
        return self.process_transport_result()

    def update_data(self, endpoint: str, body: BaseModel, *ignore, **kwargs):
        self.connection.request(
            "PUT", self._get_endpoint(endpoint), body=self._get_body(body), headers=self.get_headers()
        )
        return self.process_transport_result()

    def patch_data(self, endpoint: str, *ignore, **kwargs):
        self.connection.request("PATCH", self._get_endpoint(endpoint), headers=self.get_headers())
        return self.process_transport_result()

    def process_transport_result(self):
        result = self.connection.getresponse()
        if result.status > requests.codes.created:
            status = result.status
            try:
                result = json.load(result)
            except (JSONDecodeError, ValueError):
                result = {"success": False, "message": "Unexpected response json format"}
                self._error_handler.handle(status, result)
            self._error_handler.handle(status, {"success": False, "message": result.get("reason", None)})
        return json.load(result)

    @abc.abstractmethod
    def get_headers(self) -> dict:
        raise NotImplementedError

    @staticmethod
    def _get_query(query_params: Union[BaseModel, None]) -> str:
        if not query_params:
            return ""
        not_null_values = {k: v for k, v in query_params.dict().items() if v is not None}
        return f"?{urlencode(not_null_values)}"


class HttpAuthTransportAdapter(HttpTransportAdapter):
    @classmethod
    def validate(cls) -> bool:
        return all(
            setting is not None
            for setting in (
                cls.configuration.ctm_access_key,
                cls.configuration.ctm_secret_key,
                cls.configuration.ctm_account_id,
            )
        )

    def _get_secrets(self) -> str:
        return f"{self.configuration.ctm_access_key}:{self.configuration.ctm_secret_key}"

    @lru_cache()
    def get_auth(self) -> str:
        return base64.standard_b64encode(self._get_secrets().encode()).decode()

    @lru_cache()
    def _get_auth_header(self) -> dict:
        return dict(Authorization=f"Basic {self.get_auth()}")

    def get_headers(self) -> dict:
        headers = copy.deepcopy(self._headers)
        headers.update(self._get_auth_header())
        return headers

    def _get_endpoint(self, endpoint: str):
        return f"{self.configuration.ctm_api_endpoint}/accounts/{self.configuration.ctm_account_id}/{endpoint}"


class HttpAuthTransportAdapterForAccounts(HttpAuthTransportAdapter):
    def _get_endpoint(self, endpoint: str):
        return f"{self.configuration.ctm_api_endpoint}/accounts"


class HttpFormBoundaryTransportAdapter(FormBoundaryTransportAdapterInterface, HttpTransportAdapter):
    def _get_body(self, body: BaseModel) -> str:
        return urlencode(body.dict())

    @classmethod
    def validate(cls) -> bool:
        return True

    def get_headers(self) -> dict:
        return self._headers
