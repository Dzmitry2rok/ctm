import os
import logging

from call_tracking.sdk.v1 import modules
from call_tracking.sdk.v1.application.transport.http.transport import (
    HttpAuthTransportAdapter,
    HttpAuthTransportAdapterForAccounts,
)
from call_tracking.sdk.v1.configuration.factory import Configuration

logger = logging.getLogger(__name__)

# create configuration with sensitive data
configuration = Configuration().create_own(
    access_key=os.getenv("ACCESS_KEY"), secret_key=os.getenv("SECRET_KEY"), account_id=os.getenv("ACCOUNT_ID")
)

# init a new transport client(according to configuration)
http_transport_auth = HttpAuthTransportAdapter.create(configuration)
http_transport_accounts = HttpAuthTransportAdapterForAccounts.create(configuration)


def example_activity():
    # initialize sdk module for activities(call/forms CTM)
    activities: modules.ActivitiesModule = modules.ActivitiesModule.create(http_transport_auth)

    # get activity list (paged)
    activities.query.get_list_of_activities()  # noqa
    # get activity by id
    # tag = activities.command.add_tag_by_activity_id(2147845618, "test2-tag") # noqa
    activities.command.update_tag_list(
        2147845618, known_tags=["test-1", "test-2"], tags=["test-3"]
    )  # added only test-3 tag
    activities.query.get_activity_details_by_id(2147845618)

    s_r_dto = activities.command.create_sale_record_dto(
        call_id=2147845618,
        name="test_python_sdk",
        value=4.3,
        conversion=True,
        score=2,
    )
    # add sale record information
    activities.command.create_sale_record(sale_record_dto=s_r_dto)
    # delete sale record information
    activities.command.delete_sale_record(activity_id=2147845618)
    # webhook_data = {}
    process_webhook = activities.query.process_webhook({})
    activities.command.assign_agent(2147845618, "USRB927819239392CA1FC600F61D33A1640")
    logger.debug(process_webhook)


def example_webhook():
    webhook = modules.WebhookModule.create(http_transport_auth)
    webhook_by_id = webhook.query.get_webhook_by_id(182956)
    logger.debug(webhook_by_id)
    dto = webhook.command.build_webhook_dto(  # noqa
        weburl="https://putsreq.com/7wnTaUfKVL4ME3Wsefkd", name="test_webhook"
    )
    # webhook.command.create_webhook(dto)

    webhook_list = webhook.query.get_webhooks()
    logger.debug(webhook_list)
    # webhook.command.delete_webhook(182956)


def example_accounts():
    accounts = modules.AccountsModule.create(http_transport_accounts)
    accounts.query.get_accounts_list()


def example_users():
    users = modules.UserModule.create(http_transport_auth)
    users.query.get_user_short_info_list()


if __name__ == "__main__":
    example_accounts()
    example_users()
    example_activity()
    example_webhook()
